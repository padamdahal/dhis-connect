	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>&copy; Sailor Theme - All Right Reserved</p>
                        <div class="credits">
                            <!-- 
                                All the links in the footer should remain intact. 
                                You can delete the links only if you purchased the pro version.
                                Licensing information: https://bootstrapmade.com/license/
                                Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Sailor
                            -->
                            <a href="https://bootstrapmade.com/free-business-bootstrap-themes-website-templates/">Business Bootstrap Themes</a> by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                        </div>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

<!-- Placed at the end of the document so the pages load faster -->
<script src="http://evacms.local/static/sailor/js/jquery.min.js"></script>
<script src="http://evacms.local/static/sailor/js/modernizr.custom.js"></script>
<script src="http://evacms.local/static/sailor/js/jquery.easing.1.3.js"></script>
<script src="http://evacms.local/static/sailor/js/bootstrap.min.js"></script>
<script src="http://evacms.local/static/sailor/plugins/flexslider/jquery.flexslider-min.js"></script> 
<script src="http://evacms.local/static/sailor/plugins/flexslider/flexslider.config.js"></script>
<script src="http://evacms.local/static/sailor/js/jquery.appear.js"></script>
<script src="http://evacms.local/static/sailor/js/stellar.js"></script>
<script src="http://evacms.local/static/sailor/js/classie.js"></script>
<script src="http://evacms.local/static/sailor/js/uisearch.js"></script>
<script src="http://evacms.local/static/sailor/js/jquery.cubeportfolio.min.js"></script>
<script src="http://evacms.local/static/sailor/js/google-code-prettify/prettify.js"></script>
<script src="http://evacms.local/static/sailor/js/animate.js"></script>
<script src="http://evacms.local/static/sailor/js/custom.js"></script>

	
</body>
</html>