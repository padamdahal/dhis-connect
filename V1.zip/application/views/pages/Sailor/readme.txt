Thanks for downloading this theme!

Theme Name: Sailor
Theme URL: https://bootstrapmade.com/sailor-free-bootstrap-theme/
Author: BootstrapMade
Author URL: https://bootstrapmade.com