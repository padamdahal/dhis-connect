		<div class="container">
			<div class="page-header" style="margin-top:10px;border-bottom:1px solid #ececec;">
				<div class="row">
					<div class="col-lg-2" style="padding-bottom:10px;">
						<h4 class="section-title">Navigation</h4>
						<?php echo $navigation;?>
					</div>
					<div class="col-lg-6">
						<?php echo $content;?>
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1766.343831174698!2d85.30654675920371!3d27.69604683306711!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb18518d4e8021%3A0x92981cbf20e7d934!2sTeku%2C+Kathmandu+44600!5e0!3m2!1sen!2snp!4v1443767721905" width="560" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
					<div class="col-lg-4" style="padding-bottom:10px;">
						<?php include_once('includes/sidebar-right.php');?>
					</div>
				</div>
			</div>
			
			<div class="bs-docs-section">
				<?php include_once('includes/sidebar-bottom.php');?>
			</div>