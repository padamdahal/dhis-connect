<html>
<head>
	<title>403 Forbidden</title>
</head>
<body>

<p style="position:relative;margin:0 auto;width:80%;padding:20px 10px;border:1px solid efefef;text-align:center;background:orangered;font-size:22px;color:#fff;font-family:Arial;">
	Directory access is forbidden.
</p>

</body>
</html>