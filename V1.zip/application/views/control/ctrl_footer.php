<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
    </div>
    <!-- /#wrapper -->
    <script src="<?php echo ctrl_scripts_url('jquery.js');?>"></script>
    <script src="<?php echo ctrl_scripts_url('bootstrap.min.js');?>"></script>
    <script src="<?php echo ctrl_scripts_url('admin/plugins/morris/raphael.min.js');?>"></script>
    <script src="<?php echo ctrl_scripts_url('admin/plugins/morris/morris.min.js');?>"></script>
    <script src="<?php echo ctrl_scripts_url('admin/plugins/morris/morris-data.js');?>"></script>
</body>
</html>
